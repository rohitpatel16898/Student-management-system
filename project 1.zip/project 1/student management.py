#Student management system
print("-"*100)
print("-"*100)
print()
print("     ****   WELCOME TO STUDENT MANAGEMENT SYSTEM  *****")
print("-"*100)
print("-"*100)
print("\n\n")
lst=open("sample.txt","a+")

def view_list():
    lst = open("sample.txt", "r")
    for i in lst:
        print(i.strip())  
    lst.close()
    
def insert_data():
    lst=open("sample.txt","a+")
    data=input("Enter new student name \n")
    data=data+'\n'
    lst.write(data)
    print("Student name successfully added ")
    lst.close()
    lst1=open("sample.txt","r")
    print(lst1.read())
    lst1.close()

def delete_data():
    try:
        lst="sample.txt"
        with open(lst,"r+")as file:
            name=input("\Enter the name")
            name=name+'\n'
            file.seek(0)
            var=file.readlines()
            if name in var:
                 var.remove(name)
                 print(f"name '{name.strip()}' is")

                 file.seek(0)
                 file.truncate()
                 file.write(''.join(name))
            else:
                print("name is not found in file")
    except FileNotFoundError:
        print(f"file{lst}is not found")
    except Exception as e:
        print(f"an error occured:{e}")

def search_data():
    lst = open('sample.txt', 'r')
    name = input("Enter the name: ")
    var = lst.read()
    if name in var:
        print(f"Name '{name}' is found")
    else:
        print("Name is not found")
    lst.close()

while True:
    print("please choose any option: ")
    print("*"*30,"\n")
    print("1). TO SHOW STUDENT LIST:\n")
    print("2). TO ADD NEW DATA IN RECORD:\n")
    print("3). TO DELETE DATA FROM RECORD:\n")
    print("4). TO SEARCH  DATA FROM RECORD:\n")
    print("5). EXIT: ")

    print("="*50)
    ch=int(input("press the key what operation you want"))
    print("="*50)
    
      
    if ch==1:
          view_list()
    elif ch==2:
          insert_data()
    elif ch==3:
          delete_data()
    elif ch==4:
          search_data()
    elif ch==5:
          exit()
    else:
          print("wrong option>!\n      try again....")
    print("_"*35)
    option=input("do you want to continue (y/n)")
    print("_"*35)
    if(option=="y"):
          continue
    elif(option=="n"):
          break
          



































            
    
